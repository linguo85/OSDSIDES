/* Standard C-include files */


/* Additional include files */

         
/* Functions */

void usrset(ipath, ndesv, mnlncg, nout, desvar, constr, goals)
int *ipath, *ndesv, *mnlncg, *nout;
float *desvar, *constr, *goals;
{          

	if ( *ipath == 1 || *ipath == 2 ) {
		/* Evaluate nonlinear constraints. */
		constr[0] = desvar[0] ;
		constr[1] = desvar[1] ;
	}

	if ( *ipath == 1 || *ipath == 3 ) {
		/* Specify goals(j) for each goal where j = 0, mnlcg-1 */
		goals[0] = desvar[0] ;
		goals[1] = desvar[1] ;
	}

	return;
}


void userin(ndesv, ninp, nout, desvar)
int *ndesv, *ninp, *nout;
float *desvar;
{
  return;
}


void usrout(ndesv, nout, desvar)
int *ndesv, *nout;
float *desvar;
{              
  return;
}


void usrana(ndesv, nout, desvar)
int *ndesv, *nout;
float *desvar;
{              
  return;
}


void usrmon(ndesv, ndevar, nmpri, nnlcon, nnlgoa, nout,
            desvar, devvar, condev, devfun, gval)
int *ndesv, *ndevar, *nmpri, *nnlcon, *nnlgoa, *nout;
float *desvar, *devvar, *condev, *devfun, *gval;
{              
  return;
}


void usrlin(mlincg, ndesv, nlinco, nlingo, nout, desvar, coflin, rhslin)
int *mlincg, *ndesv, *nlinco, *nlingo, *nout;
float *desvar, *coflin, *rhslin;
{          

	return;
}



